
			<nav class="navbar navbar-default navbar-transprent">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-sample" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="index.php">
						<img style="    width: 175px;
					    margin-top: -22px;" src="img/Sketchut.png" alt="">
					    </a>
										</div>
	
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="navbar-sample">
						
						<ul class="nav navbar-nav navbar-right" id="navlist">
							<li class="active"><a href="index.php">Home</a></li>
							<li><a href="about-us.php">About Us</a></li>
							<li><a href="services.php">Services</a></li> 
							<li><a href="https://www.behance.net/sketchutdecbee">Portfolio</a></li> 
							<li><a href="#">Blog</a></li> 
						</ul>
					</div>
				</div>
			</nav>

